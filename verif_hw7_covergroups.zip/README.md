# verif_hw7
